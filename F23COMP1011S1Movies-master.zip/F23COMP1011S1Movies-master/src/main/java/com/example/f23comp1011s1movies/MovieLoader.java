package com.example.f23comp1011s1movies;

public interface MovieLoader {
    public void loadMovie(String imdbID);
}
